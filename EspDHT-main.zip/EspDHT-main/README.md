An Arduino library for reading the DHT family of temperature and humidity sensors.

Written by Mark Ruys, mark@paracas.nl.
Updated by 3tawi

Features:
    Support for DHT11 and DHT22, AM2302, RHT03
    Low memory footprint
    Very small code
